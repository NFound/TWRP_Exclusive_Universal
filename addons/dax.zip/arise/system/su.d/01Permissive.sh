#!/system/bin/sh
# Permissive Mode
# Copyright (C) 2017 - Jamal2367

echo 0 > /sys/fs/selinux/enforce
